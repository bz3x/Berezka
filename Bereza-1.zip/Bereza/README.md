# Берёза — голосовой помощник для Toyota bZ3X (Android-ГУ)
1. Откройте папку в Android Studio (Gradle sync создаст wrapper).
2. Build > Build APK(s) → app/build/outputs/apk/debug/app-debug.apk
3. Установите на ГУ (USB/ADB: adb install app-debug.apk).
4. Запустите, введите API-ключ, дайте разрешения, скажите «Берёза».
Управление машиной: реализуйте CarController (CarController.kt).
Если на ГУ нет службы распознавания речи Google, нужен сторонний RecognitionService.
