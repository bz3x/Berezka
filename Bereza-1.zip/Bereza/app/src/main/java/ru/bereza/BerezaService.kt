package ru.bereza

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.concurrent.thread

class BerezaService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val ui = Handler(Looper.getMainLooper())
    private var awaiting = false
    private var speaking = false
    private lateinit var router: CommandRouter
    private val wake = Regex("бер[её]зк?[аиу]?", RegexOption.IGNORE_CASE)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("bereza", "Берёза", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "bereza")
            .setContentTitle("Берёза слушает").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        router = CommandRouter(this, CompositeCar(AaosCarController(this), NullCarController()))
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        tts?.language = Locale("ru", "RU")
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            listen()
        } else say("Распознавание речи недоступно на этом устройстве")
    }

    private fun listen() {
        ui.postDelayed({
        if (speaking) { listen(); return@postDelayed }
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        })
        }, 400)
    }

    private fun say(t: String) {
        speaking = true
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
        ui.postDelayed({ speaking = false }, 1500L + t.length * 70L)
    }

    override fun onResults(r: Bundle?) {
        val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        val m = wake.find(text)
        val cmd = when {
            m != null -> text.removeRange(0, m.range.last + 1).trim(' ', ',', '.')
            awaiting && text.isNotBlank() -> text
            else -> null
        }
        when {
            cmd == null -> {}
            cmd.isEmpty() -> { awaiting = true; say("Слушаю") }
            else -> { awaiting = false; thread { say(router.handle(cmd)) } }
        }
        listen()
    }

    override fun onError(e: Int) { listen() }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}

    override fun onDestroy() {
        recognizer?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
