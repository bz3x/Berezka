package ru.bereza

import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

object WeatherClient {
    private fun get(u: String) = JSONObject(URL(u).openConnection().apply {
        connectTimeout = 8000; readTimeout = 8000 }.getInputStream().bufferedReader().readText())

    private fun describe(code: Int) = when (code) {
        0 -> "ясно"; 1, 2 -> "малооблачно"; 3 -> "пасмурно"; 45, 48 -> "туман"
        in 51..57 -> "морось"; in 61..67 -> "дождь"; in 71..77 -> "снег"
        in 80..82 -> "ливень"; in 85..86 -> "снегопад"; in 95..99 -> "гроза"; else -> "облачно"
    }

    fun forCity(city: String): String {
        val g = get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&name=" +
            URLEncoder.encode(city, "UTF-8")).optJSONArray("results")?.optJSONObject(0)
            ?: return "Не нашла город $city"
        val w = get("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}" +
            "&longitude=${g.getDouble("longitude")}&current=temperature_2m,wind_speed_10m,weather_code" +
            "&wind_speed_unit=ms").getJSONObject("current")
        return "${g.getString("name")}: ${w.getDouble("temperature_2m").toInt()} градусов, " +
            "${describe(w.getInt("weather_code"))}, ветер ${w.getDouble("wind_speed_10m").toInt()} метров в секунду"
    }
}
