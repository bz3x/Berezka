package ru.bereza

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiClient(ctx: Context) {
    private val p = ctx.getSharedPreferences("bereza", Context.MODE_PRIVATE)

    companion object { private val history = ArrayList<Pair<String, String>>() }

    fun ask(q: String, maxTokens: Int = 300, hint: String = ""): String {
        val key = p.getString("api_key", "").orEmpty()
        if (key.isBlank()) return "Укажите API-ключ в настройках, чтобы я отвечала на вопросы"
        val msgs = JSONArray()
        synchronized(history) {
            history.takeLast(6).forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
        }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject()
            .put("model", p.getString("model", "claude-sonnet-5-5"))
            .put("max_tokens", maxTokens)
            .put("system", "Ты Берёза — добрый, весёлый голосовой помощник-медвежонок в автомобиле. " +
                "Отвечай по-русски, коротко и тепло, без форматирования и списков, чтобы это было удобно слушать. $hint")
            .put("messages", msgs)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 30000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) return "Ошибка связи с ИИ: ${c.responseCode}"
        val ans = JSONObject(c.inputStream.bufferedReader().readText())
            .getJSONArray("content").getJSONObject(0).getString("text")
        synchronized(history) { history.add("user" to q); history.add("assistant" to ans) }
        return ans
    }
}
